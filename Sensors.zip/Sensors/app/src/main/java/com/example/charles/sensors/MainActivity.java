package com.example.charles.sensors;

import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private SensorManager a;
    private Sensor l;
    private SensorEventListener sensorEventListener;
    private double mx,my,mz;
    private List<String> result_all;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b = (Button)findViewById(R.id.button1);
        Button c = (Button)findViewById(R.id.button2);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSensors(v.getContext());
            }
        });
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accl(v.getContext());
            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        a.unregisterListener(sensorEventListener);
    }

    public void showSensors(Context context){
        a = (SensorManager)context.getSystemService(Context.SENSOR_SERVICE);
        assert a != null;
        List<Sensor> l_list = a.getSensorList(Sensor.TYPE_ALL);
        result_all = new ArrayList<String>();
        for(Sensor s:l_list){
            result_all.add("Name:" + s.getName() +"\nVendor:"+ s.getVendor() +"\nVersion:"+ s.getVersion() +"\nRange:"+ s.getMaximumRange() +"\nDelay:"+ s.getMinDelay()+"\n");
        }
        ListView l_v = (ListView)findViewById(R.id.ListView1);
        ArrayAdapter<String> arr = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1,result_all);
        l_v.setAdapter(arr);
    }
    public void accl(Context context){
        a = (SensorManager)context.getSystemService(Context.SENSOR_SERVICE);
        assert a != null;
        l = a.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorEventListener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                double x =event.values[0];
                double y =event.values[1];
                double z =event.values[2];
                if(Math.abs(x-mx)>1||Math.abs(y-my)>1||Math.abs(z-mz)>1)//mx是相对于之前比较的数据。
                {
                    result_all = new ArrayList<String>();
                    ListView l_v = (ListView)findViewById(R.id.ListView1);
                    result_all.add("Acceleration force\n"+"X:"+x+"\nY"+y+"\nZ"+z+"\n");
                    result_all.add("Acceleration force Without gravity\n"+"X:"+x+"\nY"+y+"\nZ"+(z-9)+"\n");
                    ArrayAdapter<String> arr = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1,result_all);
                    l_v.setAdapter(arr);
                    l_v.setBackgroundColor(Color.BLUE);
                }
                mx=x;
                my=y;
                mz=z;

            }
            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }
        };
        a.registerListener(sensorEventListener,l,SensorManager.SENSOR_DELAY_NORMAL);
    }
}
