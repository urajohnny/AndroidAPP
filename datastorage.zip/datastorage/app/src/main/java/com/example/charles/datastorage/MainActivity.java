package com.example.charles.datastorage;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.os.StatFs;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static android.os.Environment.*;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText a = (EditText) findViewById(R.id.editText1);
        Button b = (Button) findViewById(R.id.button1);
        final TextView c = findViewById(R.id.textView);
        final SharedPreferences s = getSharedPreferences("share_sample", Context.MODE_PRIVATE);
        c.setText(s.getString("sample", ""));
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c.setText(a.getText().toString());
                SharedPreferences.Editor e = s.edit();
                e.putString("sample", a.getText().toString());
                e.commit();
            }
        });
        Button d = (Button) findViewById(R.id.button2);
        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isExternalStorageWritable()) {
                    StatFs sf = new StatFs(getExternalStorageDirectory().getPath());
                    long bytesAvailable = (long) sf.getBlockSize() * (long) sf.getBlockCount();
                    long megAvailable = bytesAvailable / 1048576 / 1024;
                    TextView result = findViewById(R.id.textView2);
                    result.setText(String.format("%d", megAvailable));
                }
            }
        });
        Button f = findViewById(R.id.button3);
        f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                Location l = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                WifiManager wm = (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if(!wm.isWifiEnabled()){
                    wm.setWifiEnabled(true);
                }
                wm.startScan();
                List<ScanResult> li= wm.getScanResults();
                List<String> re_list=showWifiList(li);
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                for(int i=0;i<re_list.size();i++){

                    re_list.set(i,new String("1-Date:"+df.format(new Date())+"\n2-Longitude:"+l.getLongitude()+" Latitude:"+l.getLatitude()+"\n3-SSID:"+re_list.get(i)+"\n"));
                }
                ListView ls_view = findViewById(R.id.ListView);
                ArrayAdapter<String> aa = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,re_list);
                ls_view.setAdapter(aa);
                ls_view.setBackgroundColor(Color.BLUE);
                try {
                    File parent_path = Environment.getExternalStorageDirectory();
                    File dir = new File(parent_path.getAbsoluteFile(), "Test");
                    dir.mkdir();
                    File file = new File(dir.getAbsoluteFile(), "content.txt");
                    file.createNewFile();
                    FileOutputStream fos = new FileOutputStream(file);
                    PrintStream ps = new PrintStream(fos);
                    for(String temp:re_list){
                        ps.print(temp);
                    }
                    ps.close();
                    fos.close();
                }catch (Exception e){

                }


            }
        });
    }
    public boolean isExternalStorageWritable() {
        String state = getExternalStorageState();
        if (MEDIA_MOUNTED.equals(state))
            return true;
        return false;
    }
    public List<String> showWifiList(List<ScanResult> list) {
        List<String> str =new ArrayList<String>();
        List<String> judgeF=new ArrayList<String>();
        int t = 1;
        int n=0;
        for (int i = 0; i < list.size(); i++) {
            String strSsid = list.get(i).SSID;
            if(strSsid == ""){
                continue;
            }
            if(!judgeF.contains(strSsid)){
                n+=1;
                judgeF.add(strSsid);
            }
            int strLevel = list.get(i).level;

            str.add( strSsid + "\n4-Signal Strength:"+ strLevel);
            t++;

        }
        return str;
    }
}
