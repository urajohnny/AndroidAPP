package com.example.charles.battery;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.LocationManager;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView battery;
    private TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        battery =findViewById(R.id.textView);
        Button b = findViewById(R.id.button);
        result = findViewById(R.id.textView1);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent batteryStatus;
                IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
                batteryStatus = getApplicationContext().registerReceiver(null,ifilter);
                int level =batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL,-1);
                int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE,-1);
                int plug = batteryStatus.getIntExtra(BatteryManager.EXTRA_PLUGGED,-1);
                float batteryPct = level/scale * 100;
                if(plug == BatteryManager.BATTERY_PLUGGED_AC){
                    battery.setText(String.format("Current level of battery is %.2f%%\n Mobile is charging via AC",batteryPct));
                }else if(plug == BatteryManager.BATTERY_PLUGGED_USB){
                    battery.setText(String.format("Current level of battery is %.2f%%\n Mobile is charging via USB",batteryPct));
                }else{
                    battery.setText(String.format("Current level of battery is %.2f%%",batteryPct));
                }

            }
        });
        Button c = findViewById(R.id.button1);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent batteryStatus;
                    IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
                    batteryStatus = getApplicationContext().registerReceiver(null, ifilter);
                    int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                    float batteryPct = level / scale * 100;

                    Thread.sleep(1000 * 60 * 10);
                    batteryStatus = getApplicationContext().registerReceiver(null, ifilter);
                    int level_1 = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale_1 = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                    float batteryPct_1 = level_1 / scale_1 * 100;
                    if (isOPenGps(getApplicationContext())) {
                        result.setText("Using GPS for 10 minutes" + "\ninital level of battery is " + batteryPct + "\nFinal Level is " + batteryPct_1 + "\nConsumed Battery is " + (batteryPct - batteryPct_1));
                    } else if (isOpenWifi(getApplicationContext())) {
                        result.setText("Using Wifi for 10 minutes" + "\ninital level of battery is " + batteryPct + "\nFinal Level is " + batteryPct_1 + "\nConsumed Battery is " + (batteryPct - batteryPct_1));
                    } else {
                        result.setText("Normal Usage for 10 minutes" + "\ninital level of battery is " + batteryPct + "\nFinal Level is " + batteryPct_1 + "\nConsumed Battery is " + (batteryPct - batteryPct_1));
                    }
                }catch (InterruptedException e) {
                        e.printStackTrace();
                }

            }
        });


    }
    public static boolean isOPenGps(Context context) {
        LocationManager locationManager
                = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        // 通过GPS卫星定位，定位级别可以精确到街（通过24颗卫星定位，在室外和空旷的地方定位准确、速度快）
        boolean gps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        // 通过WLAN或移动网络(3G/2G)确定的位置（也称作AGPS，辅助GPS定位。主要用于在室内或遮盖物（建筑群或茂密的深林等）密集的地方定位）
        boolean network = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        if (gps || network) {
            return true;
        }

        return false;
    }
    public static boolean isOpenWifi(Context context) {
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        if(!wifiManager.isWifiEnabled()) {
            return true;
        }
        return false;
    }
}
