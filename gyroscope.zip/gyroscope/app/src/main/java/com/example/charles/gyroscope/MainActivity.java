package com.example.charles.gyroscope;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;

    private Sensor magneticSensor;

    private TextView showTextView;
    private TextView showdir;

    private Sensor accelerometerSensor;

    private Sensor gyroscopeSensor;


    private static final float NS2S = 1.0f / 1000000000.0f;

    private float timestamp;
    private GeomagneticField geoField;
    private float angle[] = new float[3];
    private float tempx;
    private float tempy;
    private float tempz;
    private double head;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LocationManager l_m = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Location loc = l_m.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

        geoField = new GeomagneticField( Double.valueOf(loc.getLatitude()).floatValue(), Double.valueOf(loc.getLongitude()).floatValue(), Double.valueOf(loc.getAltitude()).floatValue(), System.currentTimeMillis());
        showTextView = (TextView) findViewById(R.id.text);
        showdir = (TextView) findViewById(R.id.textView);

        Button b = findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angle[0] =0;
                angle[1] =0;
                angle[2] =0;
            }
        });

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        magneticSensor =sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        accelerometerSensor =sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        gyroscopeSensor =sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        sensorManager.registerListener(this,gyroscopeSensor, SensorManager.SENSOR_DELAY_NORMAL);

        sensorManager.registerListener(this,magneticSensor, SensorManager.SENSOR_DELAY_NORMAL);

        sensorManager.registerListener(this,accelerometerSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override

    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

        }else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];
            double a;
            if(x > 0){
                a = 270+ Math.atan(y/x) * 180/Math.PI;
            }else if(x<0){
                a = 90+ Math.atan(y/x) * 180/Math.PI;
            }else if(x==0&&y>0){
                a = 0;
            }else {
                a=180;
            }
            if(Math.abs(a-head) > 1){
                showdir.setText("head:"+ String.valueOf(a)+"\nTrue:"+(head - geoField.getDeclination()));
            }
            head = a;
        }else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {



            if(timestamp != 0){



                final float dT = (event.timestamp -timestamp) * NS2S;



                angle[0] += event.values[0] * dT;

                angle[1] += event.values[1] * dT;

                angle[2] += event.values[2] * dT;

                float anglex = (float) Math.toDegrees(angle[0]);

                float angley = (float) Math.toDegrees(angle[1]);

                float anglez = (float) Math.toDegrees(angle[2]);
                if((Math.abs(tempx-anglex) + Math.abs(tempy-angley) + Math.abs(tempz-anglez))>1)
                    showTextView.setText("anglex:" + anglex+"\nangley:" + angley+"\nanglez:" + anglez);
                tempx = anglex;
                tempy = angley;
                tempz = anglez;
            }

        timestamp = event.timestamp;
        }
    }



    @Override

    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    //TODO Auto-generated method stub
    }



    @Override

    protected void onPause() {

    //TODO Auto-generated method stub

        super.onPause();

        sensorManager.unregisterListener(this);
    }
}

